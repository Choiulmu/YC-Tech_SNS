package com.example.chatting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChattingApplicationTests {

    @Test
    void contextLoads() {
    }

}
